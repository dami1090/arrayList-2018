#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include "proveedor.h"

typedef struct {
    int codigo;
    char descrip[51];
    float importe;
    int cantidad;
    int estado;
    char nombreProveedor[51];

}eProducto;


typedef struct
{
    int estado;
    int idProveedor;
    char nombreProveedor[51];

}eProveedor;




int cantidadCargada(eProducto lista[],int);
int inicializar(eProducto lista[],int);
int obtenerEspacioLibre(eProducto lista[],int);
int buscarProducto(eProducto lista[],int,int);
void alta(eProducto[],int,eProveedor[],int);
void mostrarTodos(eProducto[],int);
void mostrarProducto(eProducto);
int baja(eProducto[],int);
int modificar(eProducto[],int);
int buscarProveedor(eProveedor lista[],int);
void orden(eProducto[],int);
void informar(eProducto lista[],int tam,eProveedor prov[],int cant);
void informarMuchos(eProducto lista[],int tam,eProveedor prov[],int cant);
void mostrarProveedor(eProducto lista[],int tam,eProveedor prov[],int cant);
int esNumerico(char str[]);
void informarCantidad(eProducto lista[],int tam,eProveedor prov[],int cant);
#endif // FUNCIONES_H_INCLUDED
